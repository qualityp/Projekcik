﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Data
{
    public class ConnectionStringDto
    {
        public string ConnectionString { get; set; }
    }
}
