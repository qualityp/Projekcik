﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace Library.Data.Models
{
    public class Student : User
    {
      
    }
}
